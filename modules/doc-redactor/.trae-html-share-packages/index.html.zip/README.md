# REDAKTOR — Zero-Upload PDF & Image Redaction Engine

A fully client-side redaction workstation for German legal, medical and HR documents.
Files are parsed, OCR'd, reviewed and re-exported **inside the browser tab**. Nothing is
uploaded, there is no backend, and the network guard blocks every cross-origin request.

- **Target users**: law firms, clinics, HR departments handling contracts, medical records,
  payslips, client intake forms.
- **Threat model**: the browser, the local disk and the local web server are trusted; the
  internet, remote OCR APIs and cloud converters are **not**. The app is designed so that a
  hostile network or a curious CDN cannot see document bytes.
- **Hard guarantee**: exported PDFs contain **no recoverable text layer** — the original page
  objects are never copied. See [Redaction model](#5--redaction-model-why-it-is-destructive).

---

## 1 · Quick start

```bash
cd /Users/yangjie/Documents/Trae-CN/temp_20261108_02
python3 -m http.server 8010
```

Open <http://127.0.0.1:8010/>. A local HTTP server is required because the app uses native
ES modules, Web Workers and WebAssembly — `file://` is blocked by browser security rules.

Recommended browsers: Chrome / Edge 111+, Firefox 111+, Safari 16.4+ (WASM SIMD + module workers).

### First run checklist

1. Drop a PDF or image into the left rail (PDF, PNG, JPG/JPEG, WEBP, BMP, GIF).
2. Wait for the page badge to change from `SCAN` to a red count — OCR runs locally at 150 DPI.
3. Review findings on the right (`Findings` tab); hover a black box to peek at the underlying
   text and confirm the box covers the right characters.
4. Add manual boxes in `Mark` mode, or delete false positives with the trash icon.
5. Open the `Export` tab, choose DPI / format, press **Export PDF**, then download the audit
   report. Both files are generated in memory and saved by the browser.

---

## 2 · Feature tour

| Area | What it does |
|------|--------------|
| Intake | Drag & drop or file picker; multiple files are grouped by document with per-page thumbnails. |
| OCR | Local Tesseract.js WASM worker, German + English models, PSM 3 (auto page segmentation), 150 DPI raster input. |
| Detection | 15 calibrated rules + heuristic person-name recognition + user-defined terms; runs on every rule toggle without re-running OCR. |
| Review | Black boxes are drawn onto the preview; hover/selection reveals the original pixels at 32 % opacity with an accent outline so a human can verify coverage. |
| Mark mode | Drag a rectangle on the page to add a manual redaction; `Review` mode selects and deletes boxes. |
| Export | Page-by-page re-rasterisation at 150/200/300 DPI, PNG or JPEG, optional vector rectangle overlay, metadata stripped, audit JSON. |
| Offline proof | Live request counters (`External requests` / `Blocked`), CSP `connect-src 'self'`, runtime guards on fetch/XHR/WebSocket/EventSource/`sendBeacon`, and a one-click connection test. |
| Help | In-app help modal documents workflow, guarantees and the module map. |

### Keyboard shortcuts

| Key | Action |
|-----|--------|
| `1` | Review mode |
| `2` | Mark (draw) mode |
| `Delete` / `Backspace` | Delete the selected redaction |
| `Ctrl` + wheel | Zoom the canvas |
| `Esc` | Close the help modal |
| `Enter` / `Space` on dropzone | Open the file picker |

Zoom is relative to the fitted page; the toolbar `−` / `%` / `+` buttons mirror the wheel
shortcut.

---

## 3 · Architecture

No bundler, no framework, no runtime dependency. Every module is a browser-native ES module.

```
index.html ──► src/js/app.js  (orchestration only)
                 │
   ┌─────────────┼───────────────────────────────────────────────┐
   │             │                                               │
 ingest/       ocr/            detect/          view/ + ui/     export/
 sources.js    engine.js       rules.de.js      page-view.js    pdf-builder.js
 page-factory  (Tesseract)     lexicon.de.js    documents.js    (pdf-lib)
                               scanner.js       findings.js
 pdf/render.js  redact/geometry.js             rules.js/status.js/toast.js
 core/state.js  core/utils.js  core/offline-guard.js
```

| Module | Responsibility |
|--------|----------------|
| [src/js/app.js](src/js/app.js) | Event wiring, intake queue, serial OCR queue, rescan, export flow, tabs, shortcuts. No detection or PDF logic. |
| [src/js/core/state.js](src/js/core/state.js) | Single mutable app state (`pages`, `activePageId`, `selectedId`, `mode`, `zoom`, `rules`, `customTerms`, `engineLang`, `export`), tiny emitter. |
| [src/js/core/utils.js](src/js/core/utils.js) | `uid`, `clamp`, `debounce`, `escapeHtml`, `maskValue`, `downloadBlob`, `canvasToBytes`, `nextFrame`. |
| [src/js/core/offline-guard.js](src/js/core/offline-guard.js) | Rejects every non-same-origin request, counts attempts, exposes `audit` + `probeExternalConnection()`. |
| [src/js/ingest/sources.js](src/js/ingest/sources.js) | MIME/extension gate, PDF vs bitmap classification, `loadSource()`. |
| [src/js/ingest/page-factory.js](src/js/ingest/page-factory.js) | Renders PDF pages to 150 DPI canvases, downscales previews to ≤ 2600 px, guesses A4/Letter, builds thumbnails. |
| [src/js/ocr/engine.js](src/js/ocr/engine.js) | Creates a singleton Tesseract worker with absolute `workerPath`/`corePath`/`langPath`, sets PSM 3, normalises lines/words to 0–1 boxes. |
| [src/js/pdf/render.js](src/js/pdf/render.js) | pdf.js document loading with a local worker, white-background rendering, max-edge clamping. |
| [src/js/detect/rules.de.js](src/js/detect/rules.de.js) | 15 rule definitions + real validators (IBAN mod-97, Steuer-ID ISO 7064, date/phone sanity). |
| [src/js/detect/lexicon.de.js](src/js/detect/lexicon.de.js) | First names, salutations, name labels (case-insensitive form included), titles, stopwords. |
| [src/js/detect/scanner.js](src/js/detect/scanner.js) | Rebuilds line text with character offsets, maps regex hits back to word boxes, person-name heuristics, custom terms, dedupe/sort. |
| [src/js/redact/geometry.js](src/js/redact/geometry.js) | Normalised box math: clamp, union, overlap ratio, point tests, DPI-aware padding. |
| [src/js/view/page-view.js](src/js/view/page-view.js) | Canvas painting, black boxes, hover reveal, drag-to-mark, zoom, `ResizeObserver` refit. |
| [src/js/export/pdf-builder.js](src/js/export/pdf-builder.js) | New PDF construction only: raster page, burn boxes, embed image, optional vector rects, metadata wipe, audit JSON. |
| [src/js/ui/*](src/js/ui/) | Toast, document/page list, rule switches, findings list, status bar. |

### Data flow

1. **Intake** — file → `Page` record (`baseCanvas` 150 DPI, `thumbUrl`, `sizePt`, empty `lines`).
2. **OCR** — serial queue (`app.js`) → Tesseract → `lines[]` / `words[]` with normalised boxes
   (`{x, y, w, h}` in 0–1 page space). One page fails → marked `error`, queue continues.
3. **Detect** — `scanPage(page)` builds line strings, applies enabled rules and custom terms,
   maps character ranges to word boxes, pads by 3 px at page width, scores and de-duplicates.
4. **Review** — `PageView` paints the bitmap then fills every enabled detection box solid black.
5. **Export** — `exportRedactedPdf()` re-renders at the chosen DPI, burns the same normalised
   boxes into the raster, builds a brand-new PDF document, and returns a `Blob`.

Normalised coordinates are the contract between OCR, preview and export; they make the output
independent of DPI, zoom and PDF rotation.

---

## 4 · Detection rules

Defaults are tuned for German business/legal paperwork. Rules can be toggled per document
without re-running OCR (only the scan is repeated).

| ID | Label | Severity | Default | Validation |
|----|-------|----------|---------|------------|
| `iban` | IBAN | high | on | Country prefix + length + **mod-97 checksum** |
| `vatId` | VAT ID (DE) | high | on | `DE` + 9 digits, grouped formats allowed |
| `taxId` | Tax ID (Steuer-ID) | high | on | 11 digits, **ISO 7064 MOD 11,10** check digit |
| `socialSecurity` | Social security no. | high | on | 12 digits, embedded birth date must be plausible |
| `healthInsuranceId` | Health insurance no. | high | on | Letter prefix + 9–10 digits (KVNR style) |
| `email` | Email address | high | on | RFC-style local/domain pattern |
| `phone` | Phone number | high | on | `+49` / `0049` / leading `0`, separator tolerant, ≥ 7 digits |
| `streetAddress` | Street address | mid | on | `…straße/str./weg/gasse/platz` + house number |
| `postalCity` | Postcode + city | mid | on | 5-digit German postcode + capitalised city |
| `date` | Date | mid | on | `DD.MM.YYYY`, `DD/MM/YYYY`, `YYYY-MM-DD`, month names |
| `amount` | Amount | mid | on | German thousands/decimal separators + optional currency |
| `caseNumber` | Case / file number | mid | on | Keyword (`Aktenzeichen`, `Az.`, `Fall-Nr.`, …) + captured number group |
| `longDigits` | Long digit string | low | **off** | 9+ consecutive digits, not already claimed |
| `personNames` | Person name | high | on | Salutation or name label + capitalised token run |
| `personNamesLoose` | Name pair (heuristic) | low | **off** | Two adjacent capitalised tokens outside the stopword list |

### Scoring and de-duplication

`score = 1000` for manual boxes, `900` for custom terms, otherwise
`severity (high 100 / mid 60 / low 30) + confidence`. Candidates are sorted by score, then any
candidate whose **overlap ratio > 0.62** against an already-accepted box is dropped. The final
list is ordered top-to-bottom, left-to-right for stable UI and audit output.

### Adding a rule

1. Append an object to `RULES` in [rules.de.js](src/js/detect/rules.de.js):
   `{ id, kind, group, label, example, severity, defaultOn, pattern, groupIndex?, validate? }`.
2. Add a validator returning `true/false` if the pattern alone is too permissive.
3. Reload; the rule appears automatically in the `Rules` tab with its own counter.

### Custom terms

The `Rules` tab has a textarea: one term per line, case-insensitive, minimum two characters.
Terms are re-scanned on every keystroke (380 ms debounce) and are scored above heuristics.

---

## 5 · Redaction model (why it is destructive)

Overlaying a black rectangle on a PDF is **not** redaction: the text underneath stays
extractable. REDAKTOR therefore never edits the source page. For every exported page it:

1. Re-renders the page at the requested DPI (150 / 200 / 300) from the original bitmap/PDF page,
   capped at 5200 px on the longest edge.
2. Burns the accepted normalised boxes into that raster with solid `#000000` fills
   (`burnRedactions`), including page rotation handling via the shared viewport.
3. Creates a **new** `PDFDocument` (pdf-lib) and draws **only** that image, plus optional vector
   rectangles in PDF user space (`drawVectorRects`) as a belt-and-braces overlay.
4. Deletes document metadata (`Title`, `Author`, `Subject`, `Keywords` → empty; `Creator` /
   `Producer` → `REDAKTOR`) and never copies fonts, annotations, form fields, attachments,
   OCR text layers or XMP packets from the source.

Consequences:

- Text extraction from the exported PDF returns **zero characters**; there is no `/Font`
  resource and no text operators. Verified in [TEST_REPORT.md](TEST_REPORT.md).
- Raster images inside the exported file contain the burned black pixels, so even a
  re-OCR of the output cannot recover the values.
- `vectorRects` adds machine-readable rectangles for downstream DMS pipelines; turning it off
  leaves pure raster pages.
- The trade-off: exported pages are no longer selectable/searchable. That is intentional for
  redacted legal/medical output.

### Audit report (`*-redaction-report.json`)

Aggregated, content-free evidence: tool/engine identifiers, timestamp, export settings
(language, DPI, format, vector flag), totals and per-category counts, plus page dimensions.
It contains **no document text, no names, no values** — safe to attach to a case file.

---

## 6 · Offline guarantee

Three independent layers:

1. **CSP** in [index.html](index.html):
   `default-src 'self'; connect-src 'self' blob: data:; script-src 'self' 'wasm-unsafe-eval' blob:;`
   `worker-src 'self' blob:; object-src 'none'; base-uri 'none'; form-action 'none'`.
2. **Runtime guard** ([offline-guard.js](src/js/core/offline-guard.js)): wraps `fetch`,
   `XMLHttpRequest.open/send`, `WebSocket`, `EventSource`, `navigator.sendBeacon`; any URL whose
   origin differs from the page origin is rejected and counted in `window.REDAKTOR.audit`.
3. **Visible evidence**: the top-bar badge shows the live count; clicking it opens the `Export`
   tab with the audit block. **Run connection test** deliberately calls `https://example.com`
   and reports the block — expected result is `Blocked 1`, never a success.

Everything else is same-origin and local: pdf.js worker, pdf-lib, the Tesseract worker and core
WASM, and `deu`/`eng` traineddata under `vendor/`. The engine therefore works with Wi-Fi
disabled once the page is loaded, and with the page served from a machine that has no internet
route at all.

> The static server itself is local-only. Do not expose port 8010 to an untrusted network;
> the app trusts its own origin by design.

---

## 7 · Performance & limits

- OCR input is 150 DPI (≈ 1240 × 1754 px for A4). Higher DPI mainly slows OCR without improving
  accuracy on typical office scans.
- Preview bitmaps are capped at 2600 px on the longest edge; export bitmaps at 5200 px.
- OCR is serial (one worker) to keep memory bounded; progress is aggregated across pages.
- Rule/custom-term changes trigger `scanPage` only — never a second OCR pass.
- Export is sequential per page with a progress bar; 300 DPI PNG is the largest output.

Known constraints:

- Encrypted/password-protected PDFs are not supported (pdf.js password prompt is not wired).
- TIFF is rejected (browser canvas support is unreliable); convert to PNG/JPEG first.
- Handwriting and very low-quality scans reduce OCR accuracy; manual `Mark` boxes are the fallback.
- Only `deu + eng` models are bundled; adding a language is described in §8.
- Large multi-hundred-page jobs are bounded by browser memory; export one document at a time.

---

## 8 · Maintenance guide

### Update a vendored library

Replace the file under `vendor/…` and keep the classic-script UMD build names used in
`index.html`. pdf.js also requires `vendor/pdfjs/pdf.worker.min.js`; Tesseract requires
`worker.min.js`, the four `tesseract-core*` WASM pairs, and `tessdata/*.traineddata.gz`.

### Add an OCR language

1. Download `xxx.traineddata.gz` (the compact `4.0.0_best_int` build is ~1–3 MB).
2. Put it in `vendor/tessdata/`.
3. Change `engineLang` in [state.js](src/js/core/state.js) or extend the `lang` argument in
   `initEngine('deu+eng+xxx')` ([engine.js](src/js/ocr/engine.js)).
4. Keep `gzip: true` — the worker fetches `.traineddata.gz` directly.

### Debug surface

`window.REDAKTOR` exposes `{ state, audit, ocrDpi, scanPage }`. Useful calls:

```js
REDAKTOR.state.pages[0].detections        // accepted boxes with ruleId/text/score
REDAKTOR.state.pages[0].lines              // OCR lines + word boxes
REDAKTOR.scanPage(REDAKTOR.state.pages[0]) // re-run detection after a manual state change
REDAKTOR.audit                             // { external, blocked }
```

### Code conventions

- ES modules only, one responsibility per file, no globals except `window.REDAKTOR` and the
  three UMD libraries.
- Normalised 0–1 boxes everywhere; convert to pixels only at the rendering edge.
- All user-visible strings are English; no string concatenation of HTML without `escapeHtml`.

---

## 9 · Testing

Automated end-to-end verification (Chromium + Playwright, sample document, exported PDF
forensics, offline simulation) is documented in [TEST_REPORT.md](TEST_REPORT.md). Reproducible
scripts live in [tests/](tests/).

```bash
# terminal 1 — serve the app
python3 -m http.server 8010

# terminal 2 — generate sample + run the suite (dev-only deps)
cd tests && npm install --no-save playwright-core@1.55.0 pdf-lib@1.17.1
node generate-sample-pii.cjs && node e2e.cjs
```

---

## 10 · Directory map

```
.
├── index.html               # markup, CSP, UMD library tags, module entry
├── README.md                # this document
├── TEST_REPORT.md           # engineering test / delivery report
├── src/
│   ├── css/app.css          # design tokens, layout, components
│   └── js/                  # 19 ES modules (see §3)
├── tests/                   # dev-only reproducible test scripts
└── vendor/                  # pinned offline assets
    ├── pdfjs/               # pdf.js 3.11.174 + worker
    ├── pdf-lib/             # pdf-lib 1.17.1 UMD
    ├── tesseract/           # tesseract.js 5.1.1 + worker
    ├── tesseract-core/      # SIMD / LSTM WASM cores
    └── tessdata/            # deu + eng traineddata (gzip)
```

## 11 · Third-party notices

| Component | Version | License | Role |
|-----------|---------|---------|------|
| pdf.js | 3.11.174 | Apache-2.0 | PDF parsing and rasterisation |
| pdf-lib | 1.17.1 | MIT | New PDF construction / image embedding |
| tesseract.js | 5.1.1 | Apache-2.0 | WASM OCR worker |
| tesseract.js-core | 5.1.1 | Apache-2.0 | LSTM/SIMD WASM builds |
| tessdata `deu`, `eng` | 4.0.0 best_int | Apache-2.0 | Language models |

All assets are vendored locally; the app performs no package installation and no CDN fetch at
runtime.
